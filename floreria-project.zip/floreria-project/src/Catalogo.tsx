import React, { useState } from 'react';
import { ShoppingCart, Heart, MessageCircle, Phone, Mail, Instagram, X, Sparkles, Send } from 'lucide-react';

const Catalogo = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [aiMessages, setAiMessages] = useState([
    { role: 'assistant', content: '¡Hola! 👋 Soy tu asistente virtual de Flores Any. ¿En qué puedo ayudarte hoy? Puedo ayudarte a elegir el ramo perfecto para cualquier ocasión.' }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  const categories = ['Todos', 'Romántico', 'Primavera', 'Premium', 'Tropical', 'Relajante', 'Celebración'];

  const products = [
    {
      id: 1,
      name: "Ramo Romantic Rose",
      price: 45.00,
      image: "https://cdn.pixabay.com/photo/2017/02/15/13/40/tulips-2068692_640.jpg",
      description: "Elegante ramo de rosas rojas premium con follaje verde",
      category: "Romántico"
    },
    {
      id: 2,
      name: "Bouquet Spring Dreams",
      price: 38.00,
      image: "https://cdn.pixabay.com/photo/2020/04/24/11/37/flowers-5087113_640.jpg",
      description: "Mezcla de flores de temporada en tonos pastel",
      category: "Primavera"
    },
    {
      id: 3,
      name: "Arreglo Garden Delight",
      price: 52.00,
      image: "https://cdn.pixabay.com/photo/2018/03/28/15/43/tulips-3269148_640.jpg",
      description: "Combinación de tulipanes y rosas en canasta rústica",
      category: "Premium"
    },
    {
      id: 4,
      name: "Ramo Sunset Passion",
      price: 42.00,
      image: "https://cdn.pixabay.com/photo/2018/08/21/23/29/sunflower-3622598_640.jpg",
      description: "Girasoles y flores naranjas con toque tropical",
      category: "Tropical"
    },
    {
      id: 5,
      name: "Bouquet Pure Elegance",
      price: 55.00,
      image: "https://cdn.pixabay.com/photo/2020/04/28/10/37/peonies-5103095_640.jpg",
      description: "Ramo de peonías blancas y rosas delicadas",
      category: "Premium"
    },
    {
      id: 6,
      name: "Arreglo Lavender Fields",
      price: 40.00,
      image: "https://cdn.pixabay.com/photo/2019/07/15/18/19/lavender-4339313_640.jpg",
      description: "Flores lilas y lavanda con eucalipto aromático",
      category: "Relajante"
    },
    {
      id: 7,
      name: "Celebración Multicolor",
      price: 48.00,
      image: "https://cdn.pixabay.com/photo/2017/08/06/17/58/gerbera-2594719_640.jpg",
      description: "Gerberas y flores vibrantes para celebraciones especiales",
      category: "Celebración"
    },
    {
      id: 8,
      name: "Orquídeas Exóticas",
      price: 65.00,
      image: "https://cdn.pixabay.com/photo/2017/08/02/16/36/orchid-2571719_640.jpg",
      description: "Elegantes orquídeas blancas en arreglo premium",
      category: "Premium"
    },
    {
      id: 9,
      name: "Ramo Tropical Paradise",
      price: 50.00,
      image: "https://cdn.pixabay.com/photo/2020/05/17/01/27/flowers-5180437_640.jpg",
      description: "Flores exóticas tropicales con hojas verdes intensas",
      category: "Tropical"
    }
  ];

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  });

  const handleQuoteSubmit = () => {
    if (formData.name && formData.phone && formData.email && formData.message) {
      alert('¡Gracias! Nos pondremos en contacto contigo pronto para tu cotización personalizada.');
      setShowQuoteForm(false);
      setFormData({ name: '', phone: '', email: '', message: '' });
    } else {
      alert('Por favor completa todos los campos');
    }
  };

  const filteredProducts = selectedCategory === 'Todos' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const handleAIChat = async () => {
    if (!userInput.trim()) return;

    const newUserMessage = { role: 'user', content: userInput };
    setAiMessages([...aiMessages, newUserMessage]);
    setUserInput('');
    setIsAiThinking(true);

    try {
      const conversationHistory = [...aiMessages, newUserMessage];
      
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: `Eres un asistente virtual amigable y experto de "FloraMía", una floristería elegante y sofisticada. Tu trabajo es ayudar a los clientes a elegir flores perfectas para sus ocasiones especiales. 

Catálogo disponible:
${products.map(p => `- ${p.name} ($${p.price}): ${p.description} [${p.category}]`).join('\n')}

Sé cálido, profesional y haz recomendaciones personalizadas basadas en la ocasión, presupuesto y preferencias del cliente. Responde en español de forma concisa y amigable.`,
          messages: conversationHistory.map(msg => ({
            role: msg.role,
            content: msg.content
          }))
        })
      });

      const data = await response.json();
      const assistantMessage = data.content
        .filter(item => item.type === 'text')
        .map(item => item.text)
        .join('\n');

      setAiMessages([...conversationHistory, { role: 'assistant', content: assistantMessage }]);
    } catch (error) {
      setAiMessages([...aiMessages, newUserMessage, { 
        role: 'assistant', 
        content: 'Lo siento, tuve un problema al procesar tu mensaje. Por favor, intenta de nuevo o contáctanos directamente.' 
      }]);
    } finally {
      setIsAiThinking(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f5ebe0] via-[#faf6f1] to-[#f5ebe0]">
      {/* Header */}
      <header className="bg-[#f5ebe0]/95 backdrop-blur-md shadow-sm sticky top-0 z-50 border-b border-[#8b3a3a]/10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-14 h-14 bg-[#8b3a3a] rounded-full flex items-center justify-center shadow-lg">
                <span className="text-2xl font-serif italic text-[#f5ebe0]" style={{fontFamily: 'Georgia, serif'}}>FR</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-[#8b3a3a]" style={{fontFamily: 'Georgia, serif', letterSpacing: '0.05em'}}>
                  FloraMia
                </h1>
                <p className="text-xs text-[#8b3a3a]/70" style={{fontFamily: 'Georgia, serif'}}>flower studio • Est. 2025</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setShowAIChat(true)}
                className="flex items-center space-x-2 bg-[#8b3a3a] text-[#f5ebe0] px-4 py-2 rounded-full hover:shadow-lg transition-all hover:bg-[#6d2e2e]"
              >
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline text-sm font-semibold">Asistente IA</span>
              </button>
              <button className="p-2 hover:bg-[#8b3a3a]/10 rounded-full transition-colors relative">
                <ShoppingCart className="w-5 h-5 text-[#8b3a3a]" />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#8b3a3a] text-[#f5ebe0] text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cart.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl font-bold text-[#8b3a3a] mb-4" style={{fontFamily: 'Georgia, serif'}}>
            Flores Frescas para cada
            <span className="text-[#6d2e2e]"> Ocasión</span>
          </h2>
          <p className="text-xl text-[#8b3a3a]/80 mb-8 max-w-2xl mx-auto" style={{fontFamily: 'Georgia, serif'}}>
            Ramos artesanales diseñados con amor. Entregas el mismo día disponibles.
          </p>
          <button
            onClick={() => setShowQuoteForm(true)}
            className="bg-[#8b3a3a] text-[#f5ebe0] px-8 py-4 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300 hover:bg-[#6d2e2e]"
          >
            Solicitar Cotización Personalizada
          </button>
        </div>
      </section>

      {/* Category Filter */}
      <section className="max-w-7xl mx-auto px-4 mb-8">
        <div className="flex flex-wrap justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full font-semibold transition-all ${selectedCategory === category
                  ? 'bg-[#8b3a3a] text-[#f5ebe0] shadow-lg'
                  : 'bg-white text-[#8b3a3a] hover:bg-[#f5ebe0] border border-[#8b3a3a]/20'}`}
              style={{fontFamily: 'Georgia, serif'}}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      {/* Products Grid */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12 text-[#8b3a3a]" style={{fontFamily: 'Georgia, serif'}}>
          {selectedCategory === 'Todos' ? 'Nuestro Catálogo Completo' : `Categoría: ${selectedCategory}`}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 cursor-pointer"
              onClick={() => setSelectedProduct(product)}
            >
              <div className="relative h-64 overflow-hidden bg-gray-100">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentElement.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-pink-200 to-rose-300"><span class="text-6xl">🌺</span></div>`;
                  }}
                />
                <div className="absolute top-4 right-4 bg-[#f5ebe0]/95 backdrop-blur-sm px-3 py-1 rounded-full border border-[#8b3a3a]/20">
                  <span className="text-xs font-semibold text-[#8b3a3a]">{product.category}</span>
                </div>
              </div>
              <div className="p-6">
                <h4 className="text-xl font-bold text-[#8b3a3a] mb-2" style={{fontFamily: 'Georgia, serif'}}>{product.name}</h4>
                <p className="text-[#8b3a3a]/70 text-sm mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-bold text-[#8b3a3a]">${product.price.toFixed(2)}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setCart([...cart, product]);
                      alert('¡Producto agregado! Contáctanos para finalizar tu pedido.');
                    }}
                    className="bg-[#8b3a3a] text-[#f5ebe0] px-6 py-2 rounded-full hover:shadow-md transition-all hover:bg-[#6d2e2e]"
                  >
                    Agregar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI Chat Modal */}
      {showAIChat && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full h-[600px] flex flex-col relative">
            <div className="bg-[#8b3a3a] p-6 rounded-t-3xl flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-[#f5ebe0] rounded-full flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-[#8b3a3a]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#f5ebe0]" style={{fontFamily: 'Georgia, serif'}}>Asistente Virtual IA</h3>
                  <p className="text-[#f5ebe0]/80 text-sm">Powered by Claude AI</p>
                </div>
              </div>
              <button
                onClick={() => setShowAIChat(false)}
                className="p-2 hover:bg-[#f5ebe0]/20 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-[#f5ebe0]" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {aiMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-4 rounded-2xl ${msg.role === 'user'
                        ? 'bg-[#8b3a3a] text-[#f5ebe0]'
                        : 'bg-white text-[#8b3a3a] border border-[#8b3a3a]/10'}`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {isAiThinking && (
                <div className="flex justify-start">
                  <div className="bg-white text-[#8b3a3a] p-4 rounded-2xl border border-[#8b3a3a]/10">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-[#8b3a3a] rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-[#8b3a3a] rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      <div className="w-2 h-2 bg-[#8b3a3a] rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-[#8b3a3a]/10">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAIChat()}
                  placeholder="Escribe tu mensaje..."
                  className="flex-1 px-4 py-3 border border-[#8b3a3a]/20 rounded-xl focus:ring-2 focus:ring-[#8b3a3a] focus:border-transparent outline-none"
                  disabled={isAiThinking}
                />
                <button
                  onClick={handleAIChat}
                  disabled={isAiThinking || !userInput.trim()}
                  className="bg-[#8b3a3a] text-[#f5ebe0] p-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#6d2e2e]"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quote Form Modal */}
      {showQuoteForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 relative">
            <button
              onClick={() => setShowQuoteForm(false)}
              className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
            <h3 className="text-2xl font-bold text-[#8b3a3a] mb-6" style={{fontFamily: 'Georgia, serif'}}>Solicitar Cotización</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#8b3a3a] mb-2">Nombre</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 border border-[#8b3a3a]/20 rounded-xl focus:ring-2 focus:ring-[#8b3a3a] focus:border-transparent outline-none transition-all"
                  placeholder="Tu nombre completo"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#8b3a3a] mb-2">Teléfono</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-4 py-3 border border-[#8b3a3a]/20 rounded-xl focus:ring-2 focus:ring-[#8b3a3a] focus:border-transparent outline-none transition-all"
                  placeholder="+507 0000-0000"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#8b3a3a] mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 border border-[#8b3a3a]/20 rounded-xl focus:ring-2 focus:ring-[#8b3a3a] focus:border-transparent outline-none transition-all"
                  placeholder="tu@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#8b3a3a] mb-2">Mensaje</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full px-4 py-3 border border-[#8b3a3a]/20 rounded-xl focus:ring-2 focus:ring-[#8b3a3a] focus:border-transparent outline-none transition-all resize-none"
                  rows="4"
                  placeholder="Cuéntanos sobre tu evento y preferencias..."
                />
              </div>
              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowQuoteForm(false)}
                  className="flex-1 px-6 py-3 border border-[#8b3a3a]/30 rounded-xl hover:bg-[#f5ebe0] transition-colors text-[#8b3a3a]"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleQuoteSubmit}
                  className="flex-1 bg-[#8b3a3a] text-[#f5ebe0] px-6 py-3 rounded-xl hover:shadow-lg transition-all hover:bg-[#6d2e2e]"
                >
                  Enviar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50" onClick={() => setSelectedProduct(null)}>
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="grid md:grid-cols-2">
              <div className="w-full h-96 bg-gray-100">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentElement.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-pink-200 to-rose-300"><span class="text-9xl">🌺</span></div>`;
                  }}
                />
              </div>
              <div className="p-8">
                <div className="mb-4">
                  <span className="bg-[#f5ebe0] text-[#8b3a3a] px-3 py-1 rounded-full text-sm font-semibold border border-[#8b3a3a]/20">
                    {selectedProduct.category}
                  </span>
                </div>
                <h3 className="text-3xl font-bold text-[#8b3a3a] mb-4" style={{fontFamily: 'Georgia, serif'}}>{selectedProduct.name}</h3>
                <p className="text-[#8b3a3a]/70 mb-6">{selectedProduct.description}</p>
                <div className="text-4xl font-bold text-[#8b3a3a] mb-6">
                  ${selectedProduct.price.toFixed(2)}
                </div>
                <button
                  onClick={() => {
                    setCart([...cart, selectedProduct]);
                    setSelectedProduct(null);
                    alert('¡Producto agregado! Contáctanos para finalizar tu pedido.');
                  }}
                  className="w-full bg-[#8b3a3a] text-[#f5ebe0] py-4 rounded-xl font-semibold hover:shadow-lg transition-all mb-3 hover:bg-[#6d2e2e]"
                >
                  Agregar al Carrito
                </button>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="w-full border border-[#8b3a3a]/30 py-4 rounded-xl hover:bg-[#f5ebe0] transition-colors text-[#8b3a3a]"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Contact Section */}
      <section className="bg-[#8b3a3a] py-16 px-4">
        <div className="max-w-4xl mx-auto text-center text-[#f5ebe0]">
          <h3 className="text-3xl font-bold mb-8" style={{fontFamily: 'Georgia, serif'}}>¿Listo para ordenar?</h3>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="https://wa.me/50700000000"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 bg-[#f5ebe0] text-[#8b3a3a] px-6 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              <span>WhatsApp</span>
            </a>
            <a
              href="tel:+50700000000"
              className="flex items-center space-x-2 bg-[#f5ebe0] text-[#8b3a3a] px-6 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
            >
              <Phone className="w-5 h-5" />
              <span>Llamar</span>
            </a>
            <a
              href="mailto:flores@floramia.com"
              className="flex items-center space-x-2 bg-[#f5ebe0] text-[#8b3a3a] px-6 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
            >
              <Mail className="w-5 h-5" />
              <span>Email</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2d1a1a] text-[#f5ebe0] py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex justify-center space-x-6 mb-6">
            <Instagram className="w-6 h-6 cursor-pointer hover:text-[#8b3a3a] transition-colors" />
            <MessageCircle className="w-6 h-6 cursor-pointer hover:text-[#8b3a3a] transition-colors" />
            <Mail className="w-6 h-6 cursor-pointer hover:text-[#8b3a3a] transition-colors" />
          </div>
          <p className="text-[#f5ebe0]/80" style={{fontFamily: 'Georgia, serif'}}>© 2025 FloraMía. Todos los derechos reservados.</p>
          <p className="text-[#f5ebe0]/60 text-sm mt-2">flower studio • Arco Iris, Colón, Panamá</p>
        </div>
      </footer>
    </div>
  );
};

export default Catalogo;
