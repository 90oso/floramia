import Catalogo from './Catalogo';
import './App.css';

function App() {
  return (
    <Catalogo />
  );
}

export default App;